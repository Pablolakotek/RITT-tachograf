# -*- coding: utf-8 -*-
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem
from PySide6.QtCore import Qt, Signal
from ritt.ui.widgets import CircularProgress
from ritt.ui.theme import GOLD, ACCENT_WARN

class BreaksTab(QWidget):
    """Widok: przyciski przerw, timer, historia."""
    break15Clicked = Signal()
    break30Clicked = Signal()
    break45Clicked = Signal()
    toggleBreakClicked = Signal()

    def __init__(self, tr: dict):
        super().__init__()
        self.tr = tr
        root = QVBoxLayout(self); root.setContentsMargins(10,10,10,10); root.setSpacing(10)

        # Przyciski
        card_btn = QWidget(); card_btn.setObjectName("Card")
        bl = QVBoxLayout(card_btn); bl.setContentsMargins(10,10,10,10)
        self.lbl_split_hint = QLabel(self.tr["split_hint"]); self.lbl_split_hint.setStyleSheet("color:#c9c9cb;")
        bl.addWidget(self.lbl_split_hint)

        row = QHBoxLayout()
        self.btn_15 = QPushButton("🚚 " + self.tr["btn_break_15"]); self.btn_15.setProperty("gold", True)
        self.btn_30 = QPushButton("🚚 " + self.tr["btn_break_30"]); self.btn_30.setProperty("gold", True)
        self.btn_45 = QPushButton("🚚 " + self.tr["btn_break_45"]); self.btn_45.setProperty("gold", True)
        row.addWidget(self.btn_15); row.addWidget(self.btn_30); row.addWidget(self.btn_45)
        bl.addLayout(row)
        root.addWidget(card_btn)

        # Timer
        card_t = QWidget(); card_t.setObjectName("Card")
        tl = QVBoxLayout(card_t); tl.setContentsMargins(10,10,10,10)
        self.lbl_timer = QLabel(self.tr["break_timer"])
        self.g_break = CircularProgress(max_value=1, value=0, thickness=18, fg=GOLD, text="--:--")
        tl.addWidget(self.lbl_timer); tl.addWidget(self.g_break)
        root.addWidget(card_t)

        # Historia
        card_h = QWidget(); card_h.setObjectName("Card")
        hl = QVBoxLayout(card_h); hl.setContentsMargins(10,10,10,10)
        self.lbl_hist = QLabel(self.tr["break_history"])
        self.tbl = QTableWidget(0, 4)
        self.tbl.setHorizontalHeaderLabels([self.tr["col_when"], self.tr["col_type"], self.tr["col_dur"], self.tr["col_effect"]])
        self.tbl.horizontalHeader().setStretchLastSection(True)
        hl.addWidget(self.lbl_hist); hl.addWidget(self.tbl)
        root.addWidget(card_h)

        # Toggle
        self.btn_toggle = QPushButton(self.tr["btn_start_break"]); self.btn_toggle.setProperty("gold", True)
        root.addWidget(self.btn_toggle)

        # Sygnały
        self.btn_15.clicked.connect(self.break15Clicked.emit)
        self.btn_30.clicked.connect(self.break30Clicked.emit)
        self.btn_45.clicked.connect(self.break45Clicked.emit)
        self.btn_toggle.clicked.connect(self.toggleBreakClicked.emit)

    # ------- API -------
    def set_break_button_text(self, is_on_break: bool, tr: dict | None = None):
        if tr: self.tr = tr
        self.btn_toggle.setText(self.tr["btn_toggle_break"] if is_on_break else self.tr["btn_start_break"])

    def set_countdown(self, total: int, remaining: int):
        if total <= 0:
            self.g_break.setMaximum(1); self.g_break.setValue(0); self.g_break.setText("--:--"); return
        elapsed = max(0, total - remaining)
        self.g_break.setMaximum(total)
        self.g_break.setValue(elapsed)
        m = remaining // 60; s = remaining % 60
        self.g_break.setText(f"{m:02d}:{s:02d}")
        if remaining <= 60: self.g_break.setColors(fg=ACCENT_WARN, bg="#233")
        else: self.g_break.setColors(fg=GOLD, bg="#233")

    def reset_countdown(self):
        self.g_break.setMaximum(1); self.g_break.setValue(0); self.g_break.setText("--:--")

    def append_history(self, when_txt: str, type_txt: str, dur_txt: str, eff_txt: str):
        r = self.tbl.rowCount(); self.tbl.insertRow(r)
        self.tbl.setItem(r, 0, QTableWidgetItem(when_txt))
        self.tbl.setItem(r, 1, QTableWidgetItem(type_txt))
        self.tbl.setItem(r, 2, QTableWidgetItem(dur_txt))
        self.tbl.setItem(r, 3, QTableWidgetItem(eff_txt))

    def apply_tr(self, tr: dict):
        self.tr = tr
        self.lbl_split_hint.setText(self.tr["split_hint"])
        self.lbl_timer.setText(self.tr["break_timer"])
        self.lbl_hist.setText(self.tr["break_history"])
        self.tbl.setHorizontalHeaderLabels([self.tr["col_when"], self.tr["col_type"], self.tr["col_dur"], self.tr["col_effect"]])
        self.btn_15.setText("🚚 " + self.tr["btn_break_15"])
        self.btn_30.setText("🚚 " + self.tr["btn_break_30"])
        self.btn_45.setText("🚚 " + self.tr["btn_break_45"])
        # toggle tekst ustawiany przez set_break_button_text(...)
