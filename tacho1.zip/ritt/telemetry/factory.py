# -*- coding: utf-8 -*-
import os
from ritt.telemetry.sim import TelemetrySIM
from ritt.telemetry.http import TelemetryHTTP
from ritt.telemetry.dll import TelemetryDLL
from ritt.config import CFG

def build_provider():
    mode = CFG["mode"]
    if mode == "dll":
        dll_path = CFG["dll_path"]
        # Funbit telemetry-server.dll nie wystawia API do ctypes → przełącz na HTTP
        if dll_path and "telemetry-server" in os.path.basename(dll_path).lower():
            print("Detected Funbit telemetry-server.dll → switching to HTTP provider")
            return TelemetryHTTP(CFG["http_url"], speed_scale=CFG["speed_scale"])
        prov = TelemetryDLL(dll_path, speed_scale=CFG["speed_scale"])
        return prov if prov.dll else TelemetrySIM()
    if mode == "http":
        return TelemetryHTTP(CFG["http_url"], speed_scale=CFG["speed_scale"])
    return TelemetrySIM()
