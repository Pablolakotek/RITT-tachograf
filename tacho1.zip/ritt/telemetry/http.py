# -*- coding: utf-8 -*-
import requests
from datetime import datetime
from ritt.telemetry.base import TelemetryBase

def _iso_to_game_minutes(iso_str: str) -> int | None:
    if not iso_str:
        return None
    try:
        s = iso_str.replace("Z", "+00:00")
        dt = datetime.fromisoformat(s)
        return dt.toordinal() * 1440 + dt.hour * 60 + dt.minute
    except Exception:
        return None

def _deep_get(d, path, default=None):
    cur = d
    for p in path.split("."):
        if not isinstance(cur, dict) or p not in cur:
            return default
        cur = cur[p]
    return cur

class TelemetryHTTP(TelemetryBase):
    def __init__(self, url, speed_scale=3.6):
        self.scale = speed_scale
        self.urls = [url]
        base = url.rstrip("/")
        if "/api/ets2/telemetry" not in base:
            self.urls.append("http://127.0.0.1:25555/api/ets2/telemetry")
        if "/api/telemetry" not in base:
            self.urls.append("http://127.0.0.1:25555/api/telemetry")
        self._last_ok = 0
        self.s = requests.Session()

    def _try_fetch(self, url):
        r = self.s.get(url, timeout=0.6)
        r.raise_for_status()
        return r.json()

    def poll(self):
        data = {}
        src_url = None
        order = [self._last_ok] + [i for i in range(len(self.urls)) if i != self._last_ok]
        for idx in order:
            try:
                data = self._try_fetch(self.urls[idx]) or {}
                src_url = self.urls[idx]
                self._last_ok = idx
                break
            except Exception:
                continue

        # --- prędkość ---
        speed_raw = (_deep_get(data, "speed")
                     or _deep_get(data, "game.truck.speed")
                     or _deep_get(data, "truck.speed")
                     or 0.0)
        try:
            speed = float(speed_raw)
        except Exception:
            speed = 0.0
        speed_kmh = speed if speed > 200 else speed * self.scale

        # --- czas gry ---
        game_time_iso = _deep_get(data, "game.time")       # "0001-01-08T21:09:00Z"
        game_minutes = _iso_to_game_minutes(game_time_iso)

        if game_minutes is None:
            alt_gm = (_deep_get(data, "gameTime")
                      or _deep_get(data, "game_time_min")
                      or _deep_get(data, "game_minutes")
                      or _deep_get(data, "time_minutes"))
            try:
                game_minutes = int(alt_gm) if alt_gm is not None else None
            except Exception:
                game_minutes = None

        paused = bool(_deep_get(data, "game.paused", _deep_get(data, "paused", False)))

        return {
            "game_minutes": game_minutes,
            "game_time_iso": game_time_iso if game_time_iso else None,
            "game_time_unix": 0,
            "speed_kmh": max(0.0, speed_kmh),
            "engine_on": True,
            "parking_brake": False,
            "paused": paused,
            "time_source": f"http:{src_url or 'n/a'}:" + ("game.time" if game_minutes is not None else "fallback"),
        }
