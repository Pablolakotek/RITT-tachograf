# -*- coding: utf-8 -*-
from dataclasses import dataclass, field
from typing import List, Dict, Optional

# --- Limity / progi (sekundy) ---
DRIVE_BEFORE_BREAK_MAX       = 4 * 3600 + 30 * 60   # 4h30
WARN_REMAIN_BREAK_MIN        = 15 * 60              # ostrzegaj poniżej 15 min

BREAK_SPLIT_FIRST_MIN        = 15 * 60              # pierwsza część splitu 15'
BREAK_SPLIT_SECOND_MIN       = 30 * 60              # druga część splitu 30'
BREAK_TOTAL_TARGET           = 45 * 60              # łącznie 45' (jedna lub split 15+30)

DAILY_REST_MIN               = 9 * 3600             # odpoczynek dobowy ≥ 9h
WEEKLY_REST_REDUCED_MIN      = 24 * 3600            # odpoczynek tyg. skrócony ≥ 24h
WEEKLY_REST_REGULAR_MIN      = 45 * 3600            # odpoczynek tyg. regularny ≥ 45h

@dataclass
class SplitState:
    """Stan splitu 45' (15' + 30')."""
    took_15: bool = False
    took_30: bool = False
    completed: bool = False

    def reset(self):
        self.took_15 = False
        self.took_30 = False
        self.completed = False

@dataclass
class BreakEvent:
    kind: str               # SHORT_15 / SHORT_30 / SHORT_45 / DAILY_9H / WEEKLY_24H / WEEKLY_45H / OTHER
    seconds: int
    completed_split: bool = False
    note: str = ""

@dataclass
class BreakManager:
    """Zarządza przerwami i liczeniem czasu do 4:30, splitami oraz resetami."""
    since_break_seconds: int = 0            # czas jazdy od ostatniej kwalifikowanej przerwy 45'
    on_break: bool = False
    current_break_elapsed: int = 0          # czas trwającej przerwy (sek gry)
    split: SplitState = field(default_factory=SplitState)
    history: List[BreakEvent] = field(default_factory=list)

    # === Pętla jazdy / przerwy ===
    def tick_drive(self, dt: int):
        """Wywołuj, gdy kierowca jedzie (sek gry)."""
        self.since_break_seconds += max(0, int(dt))

    def tick_break(self, dt: int):
        """Wywołuj w trakcie przerwy (sek gry)."""
        self.current_break_elapsed += max(0, int(dt))

    # === Sterowanie przerwą ===
    def start_break(self):
        if not self.on_break:
            self.on_break = True
            self.current_break_elapsed = 0

    def end_break(self) -> Dict:
        """Zakończ przerwę i sklasyfikuj ją wg czasu trwania."""
        if not self.on_break:
            return {"ok": False, "error": "NO_BREAK", "kind": "OTHER"}
        secs = int(self.current_break_elapsed)
        self.on_break = False
        self.current_break_elapsed = 0
        return self._classify_and_apply(secs)

    def complete_break(self, seconds: int) -> Dict:
        """
        Zakończ przerwę o znanym z góry czasie (np. odliczaną 15/30/45) i sklasyfikuj.
        Używane przez automatyczny timer.
        """
        self.on_break = False
        self.current_break_elapsed = 0
        return self._classify_and_apply(int(seconds))

    # Wsteczna zgodność (jeśli gdzieś wywołasz starą ścieżkę)
    def add_fixed_break(self, seconds: int) -> Dict:
        return self.complete_break(seconds)

    # === Klasyfikacja i skutki ===
    def _classify_and_apply(self, secs: int) -> Dict:
        """
        Zwraca:
          {
            ok: bool,
            kind: "SHORT_15"/"SHORT_30"/"SHORT_45"/"DAILY_9H"/"WEEKLY_24H"/"WEEKLY_45H"/"OTHER",
            seconds: int,
            completed_split: bool,
            reset_daily: bool,
            reset_weekly: bool,
            reset_fortnight: bool,
            error: Optional[str]
          }
        """
        reset_daily = reset_weekly = reset_fortnight = False
        completed_split = False
        kind = "OTHER"
        err: Optional[str] = None

        # --- Długie odpoczynki (dobowy/tygodniowe) ---
        if secs >= WEEKLY_REST_REGULAR_MIN:
            kind = "WEEKLY_45H"
            reset_weekly = True
            reset_fortnight = True   # uproszczenie: traktujemy jako rozdzielenie tygodni
            self._reset_split_and_since()
        elif secs >= WEEKLY_REST_REDUCED_MIN:
            kind = "WEEKLY_24H"
            reset_weekly = True
            self._reset_split_and_since()
        elif secs >= DAILY_REST_MIN:
            kind = "DAILY_9H"
            reset_daily = True
            self._reset_split_and_since()
        else:
            # --- Krótkie przerwy 45' i split ---
            if secs >= BREAK_TOTAL_TARGET:
                kind = "SHORT_45"
                self._reset_split_and_since()
            elif secs >= BREAK_SPLIT_SECOND_MIN:
                # 30' bez wcześniejszej 15' -> nie liczymy jako split (błąd)
                if not self.split.took_15:
                    kind = "SHORT_30"
                    err = "NEED_15_FIRST"
                    # nie resetujemy since_break_seconds; split się nie zmienia
                else:
                    # domykamy split 15+30 => 45'
                    kind = "SHORT_30"
                    completed_split = True
                    self._reset_split_and_since()
            elif secs >= BREAK_SPLIT_FIRST_MIN:
                kind = "SHORT_15"
                # oznaczamy, że pierwsza część splitu została zrobiona
                self.split.took_15 = True
            else:
                kind = "OTHER"

        # Zapis do historii
        self.history.append(BreakEvent(kind=kind, seconds=secs, completed_split=completed_split,
                                       note=("ERR:NEED_15_FIRST" if err == "NEED_15_FIRST" else "")))

        return {
            "ok": True if err is None else False,
            "kind": kind,
            "seconds": secs,
            "completed_split": completed_split,
            "reset_daily": reset_daily,
            "reset_weekly": reset_weekly,
            "reset_fortnight": reset_fortnight,
            "error": err
        }

    def _reset_split_and_since(self):
        """Zeruje licznik 4:30 i resetuje stan splitu po kwalifikowanej przerwie 45' lub dłuższej."""
        self.since_break_seconds = 0
        self.split.reset()

    # === Narzędzia ===
    def get_history(self) -> List[BreakEvent]:
        return list(self.history)
