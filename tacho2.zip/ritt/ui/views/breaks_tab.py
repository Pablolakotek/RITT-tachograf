# ritt/ui/views/breaks_tab.py
from __future__ import annotations
from typing import Optional, Callable, Any
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QAbstractItemView
)

def _fmt_hms(sec: Optional[int]) -> str:
    if sec is None:
        return "--:--"
    s = max(0, int(sec))
    h = s // 3600
    m = (s % 3600) // 60
    ss = s % 60
    return f"{h:d}:{m:02d}:{ss:02d}" if h else f"{m:02d}:{ss:02d}"

def _make_tr(tr_like: Any) -> Callable[[str], str]:
    if callable(tr_like):
        return tr_like
    if isinstance(tr_like, dict):
        return lambda k: tr_like.get(k, k)
    return lambda k: k

class BreaksTab(QWidget):
    """
    'Głupie' UI do PRZERW – bez logiki. Wysyła sygnały, a rodzic (main_window) robi robotę.
    Sygnały:
      - breakStartClicked()
      - break15Clicked()
      - break30Clicked()
      - break45Clicked()
      - breakStopClicked()
      - toggleBreakClicked()
    Publiczne metody:
      - set_status(on_break, elapsed_sec, target_sec)
      - add_history_entry(label, target_sec)
      - update_last_history(duration_sec, ended)
      - clear_history()
      - set_break_button_text(on_break, tr_like)
      - reset_countdown()
      - append_history(when_txt, ttxt, dur_txt, eff_txt)
      - show_block_reason(msg), clear_block_reason()
      - apply_tr(tr_like)
    """

    breakStartClicked = Signal()
    break15Clicked = Signal()
    break30Clicked = Signal()
    break45Clicked = Signal()
    breakStopClicked = Signal()
    toggleBreakClicked = Signal()

    def __init__(self, tr, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.tr = _make_tr(tr)

        # Baner z powodem blokady
        self.lbl_banner = QLabel("")
        self.lbl_banner.setVisible(False)
        self.lbl_banner.setStyleSheet("color:#fff; background:#c0392b; padding:6px; border-radius:6px;")

        self.lbl_status = QLabel(self.tr("Status: brak przerwy"))
        self.lbl_elapsed = QLabel(self.tr("Trwa: --:--"))
        self.lbl_countdown = QLabel(self.tr("Pozostało: --:--"))
        for l in (self.lbl_status, self.lbl_elapsed, self.lbl_countdown):
            l.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)

        self.btn_start = QPushButton(self.tr("PRZERWA (manual)"))
        self.btn_15 = QPushButton(self.tr("15 min"))
        self.btn_30 = QPushButton(self.tr("30 min"))
        self.btn_45 = QPushButton(self.tr("45 min"))
        self.btn_stop = QPushButton(self.tr("Zakończ PRZERWĘ"))
        self.btn_stop.setEnabled(False)

        self.table = QTableWidget(0, 5, self)
        self.table.setHorizontalHeaderLabels([
            self.tr("Lp"), self.tr("Rodzaj"), self.tr("Cel"), self.tr("Czas"), self.tr("Zakończona")
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)

        top = QHBoxLayout()
        top.addWidget(self.btn_start)
        top.addWidget(self.btn_15)
        top.addWidget(self.btn_30)
        top.addWidget(self.btn_45)
        top.addWidget(self.btn_stop)

        box = QGroupBox(self.tr("Odliczanie"))
        vbox = QVBoxLayout(box)
        vbox.addWidget(self.lbl_status)
        vbox.addWidget(self.lbl_elapsed)
        vbox.addWidget(self.lbl_countdown)

        root = QVBoxLayout(self)
        root.addWidget(self.lbl_banner)
        root.addLayout(top)
        root.addWidget(box)
        root.addWidget(self.table, 1)

        # sygnały do okna głównego
        self.btn_start.clicked.connect(self.breakStartClicked.emit)
        self.btn_start.clicked.connect(self.toggleBreakClicked.emit)
        self.btn_15.clicked.connect(self.break15Clicked.emit)
        self.btn_30.clicked.connect(self.break30Clicked.emit)
        self.btn_45.clicked.connect(self.break45Clicked.emit)
        self.btn_stop.clicked.connect(self.breakStopClicked.emit)
        self.btn_stop.clicked.connect(self.toggleBreakClicked.emit)

    # ===== publiczne API =====

    def set_status(self, on_break: bool, elapsed_sec: Optional[int], target_sec: Optional[int]):
        if not on_break:
            self.lbl_status.setText(self.tr("Status: brak przerwy"))
            self.lbl_elapsed.setText(self.tr("Trwa: --:--"))
            self.lbl_countdown.setText(self.tr("Pozostało: --:--"))
            self._set_buttons_active(False)
            return

        self.lbl_status.setText(self.tr("Status: PRZERWA"))
        self.lbl_elapsed.setText(self.tr("Trwa: ") + _fmt_hms(elapsed_sec))
        if target_sec is None:
            self.lbl_countdown.setText(self.tr("Pozostało: --:--"))
        else:
            remain = max(0, int(target_sec) - int(elapsed_sec or 0))
            self.lbl_countdown.setText(self.tr("Pozostało: ") + f"{_fmt_hms(remain)} / {_fmt_hms(target_sec)}")
        self._set_buttons_active(True)

    def add_history_entry(self, label: str, target_sec: Optional[int]):
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
        self.table.setItem(row, 1, QTableWidgetItem(label))
        self.table.setItem(row, 2, QTableWidgetItem("--:--" if target_sec is None else _fmt_hms(target_sec)))
        self.table.setItem(row, 3, QTableWidgetItem(_fmt_hms(0)))
        self.table.setItem(row, 4, QTableWidgetItem(self.tr("Trwa")))
        self.table.scrollToBottom()

    def update_last_history(self, duration_sec: int, ended: bool):
        row = self.table.rowCount() - 1
        if row < 0:
            return
        self.table.setItem(row, 3, QTableWidgetItem(_fmt_hms(duration_sec)))
        self.table.setItem(row, 4, QTableWidgetItem(self.tr("Tak") if ended else self.tr("Trwa")))

    def clear_history(self):
        self.table.setRowCount(0)

    def set_break_button_text(self, on_break: bool, tr_like=None):
        trf = self.tr if tr_like is None else _make_tr(tr_like)
        self.btn_start.setText(trf("PRZERWA (manual)"))
        self.btn_stop.setText(trf("Zakończ PRZERWĘ"))

    def reset_countdown(self):
        self.lbl_countdown.setText(self.tr("Pozostało: --:--"))

    def append_history(self, when_txt: str, ttxt: str, dur_txt: str, eff_txt: str):
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
        self.table.setItem(row, 1, QTableWidgetItem(str(ttxt)))
        self.table.setItem(row, 2, QTableWidgetItem(str(when_txt)))
        self.table.setItem(row, 3, QTableWidgetItem(str(dur_txt)))
        self.table.setItem(row, 4, QTableWidgetItem(str(eff_txt)))
        self.table.scrollToBottom()

    def show_block_reason(self, msg: str):
        if not msg:
            self.clear_block_reason()
            return
        self.lbl_banner.setText("⚠ " + str(msg))
        self.lbl_banner.setVisible(True)

    def clear_block_reason(self):
        self.lbl_banner.clear()
        self.lbl_banner.setVisible(False)

    def apply_tr(self, tr_like) -> None:
        """Odświeża napisy po zmianie języka."""
        self.tr = _make_tr(tr_like)
        self.lbl_status.setText(self.tr("Status: brak przerwy"))
        self.lbl_elapsed.setText(self.tr("Trwa: --:--"))
        self.lbl_countdown.setText(self.tr("Pozostało: --:--"))
        self.btn_start.setText(self.tr("PRZERWA (manual)"))
        self.btn_15.setText(self.tr("15 min"))
        self.btn_30.setText(self.tr("30 min"))
        self.btn_45.setText(self.tr("45 min"))
        self.btn_stop.setText(self.tr("Zakończ PRZERWĘ"))
        self.table.setHorizontalHeaderLabels([
            self.tr("Lp"), self.tr("Rodzaj"), self.tr("Cel"), self.tr("Czas"), self.tr("Zakończona")
        ])

    # ===== helpers =====
    def _set_buttons_active(self, break_active: bool):
        self.btn_start.setEnabled(not break_active)
        self.btn_15.setEnabled(not break_active)
        self.btn_30.setEnabled(not break_active)
        self.btn_45.setEnabled(not break_active)
        self.btn_stop.setEnabled(break_active)
